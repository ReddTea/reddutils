def func(foo, bar):
    return foo * bar

def add_one(number):
    return number + 1

def fib2(n):    # write Fibonacci series up to n
    a, b = 0, 1
    while a < n:
        print(a, end=' ')
        a, b = b, a+b
    print()
# pypi-AgENdGVzdC5weXBpLm9yZwIkNzY5ZjFkMDQtZDdkYS00OGRhLTlmMTAtYzc3YjVmYjc0YWFkAAIleyJwZXJtaXNzaW9ucyI6ICJ1c2VyIiwgInZlcnNpb24iOiAxfQAABiB1sIYuv2lhcY2fbV880qkmI2sIrgegju8PoXiUTojc3w
